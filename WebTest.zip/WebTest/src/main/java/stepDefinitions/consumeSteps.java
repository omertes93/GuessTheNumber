package stepDefinitions;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class consumeSteps {

	WebDriver driver;
	
	
	@Before
	public void setup() throws IOException {
		System.setProperty("webdriver.chrome.driver", Paths.get(System.getProperty("user.dir")).toRealPath() +  "\\src\\test\\java\\drivers\\chromedriver.exe");
		this.driver = new ChromeDriver();
		this.driver.manage().window().maximize();
		this.driver.manage().timeouts().pageLoadTimeout(120, TimeUnit.SECONDS);
	}
	
	
	@After() 
	public void tearDown() {
		this.driver.manage().deleteAllCookies();
		this.driver.quit();
	}
	
	
	@Given("^I access pizzahut\\.co\\.il$")
	public void i_access_pizzahut_co_il() throws Throwable {
		driver.get("https://pizzahut.co.il/");
	   
	}

	@When("^I click on sales section button$")
	public void i_click_on_sales_section_button() throws Throwable {
		String path = "//*[@id=\"off-canvas-content\"]/main/div[1]/home-page/div/div[2]/div/div/div/div[1]/a";
		WebDriverWait wait = new WebDriverWait(driver, 5);
		driver.findElement(By.xpath(path)).click();
		
	
	}

	@When("^I click on add family non gluten pizza button$")
	public void i_click_on_add_family_non_gluten_pizza_button() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		String path = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/div/div[1]/ui-view/products-page/div/ul/li[3]/main-product/article/div/div/button";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(path)));
	   driver.findElement(By.xpath(path)).click();
	    
	}

	@When("^I click on add button$")
	public void i_click_on_add_button() throws Throwable {
	WebDriverWait wait = new WebDriverWait(driver, 5);
		
		String path = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/div/div/div[1]/order-products-page/div/ul/li/main-product/article/div/div/button";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(path)));
	   driver.findElement(By.xpath(path)).click();
	   
	}

	@When("^I click on chosen extra$")
	public void i_click_on_chosen_extra() throws Throwable {
	WebDriverWait wait = new WebDriverWait(driver, 5);
		String olivesPath = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/div/div/div[1]/order-pizza-toppings-page/div/div[2]/toppings-select/div/carousel/div/div/div/div[1]/div[1]/topping/div";
		String olivesForWholePizzaPath = "//*[@id=\"topping-10-full\"]";
		String pepersPath = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/div/div/div[1]/order-pizza-toppings-page/div/div[2]/toppings-select/div/carousel/div/div/div/div[1]/div[2]/topping/div";
		String pepersForWholePizzaPath = "//*[@id=\"topping-11-full\"]";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(olivesPath)));
		driver.findElement(By.xpath(olivesPath)).click();
		driver.findElement(By.xpath(olivesForWholePizzaPath)).click();
		driver.findElement(By.xpath(pepersPath)).click();
		driver.findElement(By.xpath(pepersForWholePizzaPath)).click();
	   
	   
	   
	}

	

	@When("^I click on choose and next button$")
	public void i_click_on_choose_and_next_button() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		String path = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/div/div/div[1]/order-pizza-toppings-page/div/div[3]/div/div[2]/button";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(path)));
	   driver.findElement(By.xpath(path)).click();
		
	
		
	}

	@When("^I click on continue for payment allert button$")
	public void i_click_on_continue_for_payment_allert_button() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		String path = "/html/body/div[7]/article/a";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(path)));
	   driver.findElement(By.xpath(path)).click();
		
		
	   
	}

	@When("^I click on continue for payment button$")
	public void i_click_on_continue_for_payment_button() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 5);
		
		String path = "//*[@id=\"off-canvas-content\"]/main/div[1]/div/order-cart-page/div/div/div[2]/div/order-summary/div/div[4]/button";;
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(path)));
	   driver.findElement(By.xpath(path)).click();	
	    
		
	}

	@Then("^I should successfully be moved to the payment form$")
	public void i_should_successfully_be_moved_to_the_payment_form() throws Throwable {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		String popUp = "/html/body/div[7]/article/button";
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(popUp)));
		driver.findElement(By.xpath(popUp)).click();
		String cityPath = "#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(1) > input-typeahead > label > input";
		//String streetPath = "#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(2) > input-typeahead > label > input";
		String houseNumber = "#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(3) > input-text > label > input";
		String floorNumber = "#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(5) > input-text > label > input";
		String notes = "#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(7) > input-textarea > label > textarea";
		driver.findElement(By.cssSelector(cityPath)).sendKeys("חיפה");
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(1) > input-typeahead > label > input")));
		//driver.findElement(By.xpath("#off-canvas-content > main > div.app-main.ng-scope > div > order-method-page > div > div > div.columns.small-24.large-8.large-offset-4 > div.order-method-page__content.ng-scope > ui-view > order-delivery-new-page > div > form > div:nth-child(1) > input-typeahead > label > input")).click();
		//driver.findElement(By.cssSelector(streetPath)).sendKeys("קדימה");	
		driver.findElement(By.cssSelector(houseNumber)).sendKeys("43");
		driver.findElement(By.cssSelector(floorNumber)).sendKeys("2");
		driver.findElement(By.cssSelector(notes)).sendKeys("בדיקה 1234");
		
		
	}


	
}
